from django.contrib import admin
from .models import Feedback, Answer
# Register your models here.


admin.site.register(Feedback)
admin.site.register(Answer)