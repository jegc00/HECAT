from django.shortcuts import render
from django.views.generic.edit import FormView
from .forms import FeedbackForm, AnswerForm, GraphFeedbackForm
from django.views.generic.list import ListView
from django.views.generic.detail import DetailView
from .models import Feedback, Answer
from django.urls import reverse
from django.contrib.auth.decorators import login_required, permission_required
from django.utils.decorators import method_decorator
from django.utils.translation import gettext_lazy as _

"""
def check_hash(function):
    def wrapper(request, grupo_pk, student_pk, hash, pk=None):
        if 1:
            student = get_object_or_404(UserProfile, id=student_pk)
            if student.get_hash() == hash:
                return function(request, grupo_pk, student_pk, hash)
            else:
                raise Http404('Not found')
        else:
            raise Http404('Not found')
    return wrapper
@check_hash
"""



@method_decorator(login_required, name='dispatch')
class  AnswerDetailView(DetailView):
    model = Answer
    template_name = 'feedbacks/answer_detail.html'

@method_decorator(login_required, name='dispatch')
class FeedbackDetailView(FormView, DetailView):
    model = Feedback
    form_class = AnswerForm

    def form_valid(self, form):
        obj = form.save(commit=False)
        feedback = self.get_object()
        feedback.expert_advisor = self.request.user
        obj.feedback = feedback
        obj.save()
        feedback.save()
        return super().form_valid(form)

    def get_success_url(self):
        return reverse('thanks_expert')
    

@method_decorator(login_required, name='dispatch')
class FeedbackFormView(FormView):
    template_name = 'feedbacks/feedback_form.html'
    form_class = FeedbackForm

    def get_success_url(self):
        return reverse('thanks')

    def form_valid(self, form):
        obj = form.save(commit=False)
        obj.user = self.request.user
        form.save()
        return super().form_valid(form)
    
@method_decorator(login_required, name='dispatch')
class GraphFeedbackFormView(FormView):
    template_name = 'feedbacks/feedback_form.html'
    form_class = GraphFeedbackForm

    def get_success_url(self):
        return reverse('thanks')

    def form_valid(self, form):
        obj = form.save(commit=False)
        obj.user = self.request.user
        form.save()
        return super().form_valid(form)
    
@method_decorator(login_required, name='dispatch')    
class MyFeedBacks(ListView):
    model = Feedback
    template_name = 'feedbacks/my_feedbacks.html'
    context_object_name = 'feedbacks'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['title'] = _('This is your Labour Market Workspace')
        return context

    def get_queryset(self):
        return Feedback.objects.filter(user=self.request.user)


@method_decorator(login_required, name='dispatch')
class ExpertsFeedBacks(MyFeedBacks):
    template_name = 'feedbacks/expert_feedbacks.html'    
    def get_queryset(self):
        return Feedback.objects.filter(expert_advisor=self.request.user).order_by('user')    

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['title'] = _("Expert Advisor Workspace")
        context["by"] = _('Questions from my assigned users')        
        return context

@method_decorator(login_required, name='dispatch')
class ExpertsFreeFeedBacks(MyFeedBacks):
    template_name = 'feedbacks/expert_feedbacks.html'    
    
    def get_queryset(self):
        return Feedback.objects.filter(expert_advisor=None)   

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['title'] = _('Expert Advisor Workspace')
        context['desc'] = _('Once you have answered a user, from then on that user and his/her questions will be assigned to you.')
        context["by"] = _('Questions asked by')
        return context


