from django.urls import path
from .views import FeedbackFormView, GraphFeedbackFormView, MyFeedBacks, ExpertsFeedBacks, ExpertsFreeFeedBacks, FeedbackDetailView, AnswerDetailView
from django.views.generic import TemplateView

from ..users.views import HecatProfileView

urlpatterns = [

    path('form/', FeedbackFormView.as_view(), name='feedback_form'),      
    path('user_form/', HecatProfileView.as_view(), name='user_form'),          
    path('graph_form/', GraphFeedbackFormView.as_view(), name='graph_feedback_form'),      
    path('my_feedbacks/', MyFeedBacks.as_view(), name='my_feedbacks'),    
    path('my_feedbacks/<int:pk>', FeedbackDetailView.as_view(), name='feedback_detail'),
    path('answer/<int:pk>', AnswerDetailView.as_view(), name='answer_detail'),
    path('expert_feedbacks/', ExpertsFeedBacks.as_view(), name='expert_feedbacks'),  
    path('expert_free_feedbacks/', ExpertsFreeFeedBacks.as_view(), name='expert_free_feedbacks'),      
    path('thanks/', TemplateView.as_view(template_name='feedbacks/thanks.html'), name='thanks'),
    path('thanks/expert/', TemplateView.as_view(template_name='feedbacks/thanks_expert.html'), name='thanks_expert'),
    
]


