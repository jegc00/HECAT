from django.forms import ModelForm, HiddenInput
from .models import Feedback, Answer


class FeedbackForm(ModelForm):
    class Meta:
        model = Feedback
        fields = ['text',]

        
class GraphFeedbackForm(ModelForm):
    class Meta:
        model = Feedback
        fields = ['text', 'graph', 'graph_data']
        #widgets = {'graph': HiddenInput(), 'graph_data': HiddenInput()}
        
class AnswerForm(ModelForm):
    class Meta:
        model = Answer
        fields = ['text', 'attached_file',]