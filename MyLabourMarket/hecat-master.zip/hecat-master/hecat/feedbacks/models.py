from django.db import models
from ..users.models import HecatUser
from django.urls import reverse
from django.utils.translation import gettext_lazy as _


class Feedback(models.Model):
    user = models.ForeignKey(HecatUser, on_delete=models.PROTECT, related_name='worker_feedbacks')
    expert_advisor = models.ForeignKey(HecatUser, on_delete=models.SET_NULL, null=True, blank=True, related_name='expert_advisor_feedbacks')
    text = models.TextField(verbose_name=_('Write your question here…'))
    graph = models.CharField(max_length=100, null=True, blank=True)
    graph_data = models.JSONField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    modified_at = models.DateTimeField(auto_now=True)

    def save(self, *args, **kwargs):
        super(Feedback, self).save(*args, **kwargs)
        users_feedbacks = Feedback.objects.filter(user=self.user, expert_advisor__isnull=False)

        if users_feedbacks.exists():
            users_feedbacks1 = Feedback.objects.filter(user=self.user, expert_advisor__isnull=True)
            advisor = self.expert_advisor or users_feedbacks.first().expert_advisor
            users_feedbacks1.update(expert_advisor=advisor)


    def get_answers(self):
        return self.answer_set.all()
        
    def can_be_answered(self):
        return not self.is_answered()
    
    def is_answered(self):
        return self.get_answers().count() > 0 

    def __str__(self):
        return self.text

    def get_absolute_url(self):
        return reverse("feedback_detail", kwargs={"pk": self.pk})
    


class Answer(models.Model):
    feedback = models.ForeignKey(Feedback, on_delete=models.CASCADE)
    text = models.TextField(verbose_name=_('Answer'))
    attached_file = models.FileField(upload_to='answers/', null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    modified_at = models.DateTimeField(auto_now=True)


    def has_an_image(self):
        images_extensions = ['png','jpg','svg','bmp']
        extension = self.attached_file.url.split('.')[-1]
        if extension in images_extensions:
            return True

    def get_absolute_url(self):
        return reverse("answer_detail", kwargs={"pk": self.pk})


    def __str__(self):
        return self.text    