from django.shortcuts import render
import requests
# Create your views here.
from .models import GraphInfo, NACECode, ISCOCode
from hecat.tracking.models import Track
from hecat.users.models import HecatUser
from datetime import datetime
from django.utils.translation import gettext_lazy as _
from ..feedbacks.forms import GraphFeedbackForm
from django.contrib.auth.decorators import login_required


ISCO_COOKIE_NAME='my_iscdo_int'


def get_isco_name(code):
    try:
        return ISCOCode.objects.get(code=code).description
    except:
        return code
    
     


API_BASE_URL ="http://pinta.ijs.si/hecat/api/v1/"
API_BASE_URL_V2 ="http://pinta.ijs.si/hecat/api/v2/"

def get_years(request, initial=None):
    #year1=int(request.POST.get('quarter_year','2015'))
    #year2 =int(request.POST.get('quarter_year2','2021'))
    year1 = 2018
    year2 = 2021
    initial = initial or 2018
    years = range(initial,2022)    
    return years, year1, year2



def get_isco_list(request):
    try:
        if request.POST.get('isco_code',None):
            isco=request.POST.getlist('isco_code')
        else:
            isco=request.COOKIES.get(ISCO_COOKIE_NAME, '0110') 
            
        return isco
    except:
        return None


def get_isco(request):
    try:
        if request.POST.get('isco_code',None):
            isco=request.POST.get('isco_code')
        else:
            isco=request.COOKIES.get(ISCO_COOKIE_NAME, '0110') 
            
        return isco
    except:
        return None

def set_tracking(request):
    if request.user.is_authenticated:
        user = request.user            
        fullpath = (request.path).split("/")
        path = fullpath[-2:-1][0]
        
        if Track.objects.filter(user=user).exists():
            track = Track.objects.get(user=user)
            track_link = track.link.split(",")
            if path not in track_link: 
                track.link += ","+path
        else:
            track = Track(
                user =user,
                link = path
            )
        track.save()
        user.percentage = user.get_percentage()
        user.save()



def get_teaser(request, url1):
    year = '2022'
    isco_code = request.POST.get('isco_code')  
    url = '%s%s/%s/%s/'%(API_BASE_URL, url1, isco_code, year)    
    values = requests.get(url, timeout=10)   
    print(url)
    try:
        return values.json()   
    except:
        print(values)
        return '--'

def get_teaser_1(request):
    url = 'number_of_employed_teaser'
    return get_teaser(request, url)


def get_teaser_2(request):
    url = 'salary_teaser'
    return get_teaser(request, url)

def get_teaser_3(request):
    url = 'number_unemployed_teaser'  
    return get_teaser(request, url)

def get_teaser_4(request):
    url='unemployment_length_teaser'
    return get_teaser(request, url)    

def get_teaser_5(request):
    url = 'vacancies_teaser'
    return get_teaser(request, url)    

def get_feedback_form(request):
    if request.user.is_authenticated:
        graph_data = dict(request.POST.copy())
        graph_data.pop('csrfmiddlewaretoken', None)
        graph = request.path.split('/')[-2]
        return GraphFeedbackForm(initial={'graph':graph, 'graph_data':graph_data})
    return None


def average_number_of_entrants(request):
    return number_of_first_employed_nace(request)


def number_of_first_employed_nace(request):
    set_tracking(request)
    naces = NACECode.objects.all()
    nace=request.POST.get('NACE','1.11')
    context = {'nace':nace,"naces":naces,"year":'2020'}

    years, year1, year2 = get_years(request)
    modal = get_modal('number_of_first_employed_nace')   #average_number_of_entrants
    x_axis=[]
    list_value=[]
    title = _('New entrants per annum by economic sector')
    for year in range(year1, year2+1):
        url = API_BASE_URL+'number_of_first_employed_nace/?NACE=%s&Year=%s'%(nace, year)
        values = requests.get(url, timeout=10)   
        x_axis.append("%s"%year)

        for val in values.json():
            try:
                list_value.append(val['Data'] or 0)
            except:
                list_value.append(0)
    feedback_form = get_feedback_form(request)
    response = render(request, 'graph/number_of_first_employed_nace.html', locals())
    return response



def average_income(request):
    #set_tracking(request)
    
    isco_list = request.POST.getlist('isco_code')#get_isco_list(request)
    context = {'ISCO_CODE':isco_list,"isco_codes":isco_list,"year":'2020'}
    measurement=request.POST.get('measurement','Average')
    salary=request.POST.get('salary','Gross')
    years, year1, year2 = get_years(request, initial=2018)
    list_value=[]
    men_value=[]
    women_value=[]
    x_axis=[]
    modal = get_modal('average_income')  
    title = _('Compare Incomes') 
    iscos_graph_list = [] 
    for isco in isco_list:
        list_value=[]
        for year in range(year1, year2+1):
            
            url = '%saverage_income/?ISCO=%s&Salary=%s&Year=%s'%(API_BASE_URL, isco, salary,   year)
            values = requests.get(url, timeout=10)   
            if not "%s"%year in x_axis:
                x_axis.append("%s"%year)

            for val in values.json():
                try:
                    if val["Gender"]=="Sex - TOTAL" and val["Measurement"]==measurement:
                        list_value.append(val['Data'] or 0)
                except:
                    list_value.append(0)

        iscos_graph_list.append({'isco':get_isco_name(isco),'values':list_value})       

    feedback_form = get_feedback_form(request)
    response = render(request, 'graph/average_income.html', locals())
    return response


def get_modal(slug):
    try:
        return GraphInfo.objects.get(slug=slug)
    except:
        return ''


def estimated_vacancies(request):
    set_tracking(request)
    years, year1, year2 = get_years(request)
    list_value=[]
    x_axis=[]
    nace= request.POST.get('nace',"Activity - TOTAL [B to S]")   
    measurement= request.POST.get('measurement',"Number of job vacancies  - TOTAL")
    modal = get_modal('estimated_vacancies')
    title = _('Vacancies')

    for year in range(year1, year2+1):
        url = '%sestimated_vacancies?NACE=%s&Year=%s'%(API_BASE_URL, nace, year)
        values = requests.get(url, timeout=10)    
        x_axis.append("%s.Q1"%year)
        x_axis.append("%s.Q2"%year)        
        x_axis.append("%s.Q3"%year)        
        x_axis.append("%s.Q4"%year)     
           
        for val in values.json():
            if val['Measurement']==measurement:
                list_value.append(val['Data'] or 0)
    feedback_form = get_feedback_form(request)    
    response = render(request, 'graph/estimated_vacancies.html', locals())
    return response

def job_number_of_employed(request):
    set_tracking(request)
    
    isco_list = request.POST.getlist('isco_code')#get_isco_list(request)

    context = {"isco_codes":[],"year":'2020'}
    years, year1, year2 = get_years(request)
    modal = get_modal('job_number_of_employed')
    list_value=[]
    men_value=[]
    women_value=[]
    x_axis=[]
    title = _('Employed people')
    measurement= request.POST.get('measurement',"Number in 1000")

    iscos_graph_list = [] 
    for isco in isco_list:
        list_value=[]

        for year in range(year1, year2+1):
            values = requests.get('%snumberemployed_isco4/?ISCO=%s&Year=%s'%(API_BASE_URL, isco, year), timeout=10)    
            print(values.json())
            x_axis.append("%s"%year)
            #x_axis.append("%s.Q2"%year)        
            #x_axis.append("%s.Q3"%year)        
            #x_axis.append("%s.Q4"%year)       

            for val in values.json():
                if val["Gender"]=="Sex - TOTAL" :
                    print(val['Data'])
                    list_value.append(val['Data'] or 0)
        iscos_graph_list.append({'isco':get_isco_name(isco),'values':list_value})       



    feedback_form = get_feedback_form(request)    
    response = render(request, 'graph/job_number_of_employed.html', locals())
    #response.set_cookie(ISCO_COOKIE_NAME, isco) 
    return response
    


def number_of_first_employed_isco(request):
    set_tracking(request)

    isco=request.POST.get('isco_code','1112')
    years, year1, year2 = get_years(request)
    list_value=[]
    x_axis=[]
    modal = get_modal('number_of_first_employed_isco')    
    title = _('New entrants per annum by occupation')  
    
    for year in range(year1, year2+1):
        url = '%snumber_of_first_employed_isco/?ISCO=%s&Year=%s'%(API_BASE_URL, isco, year)
        values = requests.get(url, timeout=10)   
        x_axis.append("%s"%year)

        for val in values.json():
            try:
                list_value.append(val['Data'] or 0)
            except:
                list_value.append(0)        
    feedback_form = get_feedback_form(request)
    response = render(request, 'graph/number_of_first_employed_isco.html', locals())
    response.set_cookie(ISCO_COOKIE_NAME, isco)     
    return response



def number_of_unemployed(request):
    
    set_tracking(request)
    isco=request.POST.get('isco_code','1112')
    years, year1, year2 = get_years(request)

    list_value = []
    title = _('Unemployed')
    x_axis=[]
    modal = get_modal('number_of_unemployed')        
    
    for year in range(year1, year2+1):
        url = '%saverage_length_unemployment/?ISCO=%s&Year=%s'%(API_BASE_URL, isco, year)
        values = requests.get(url, timeout=10)   
        x_axis.append("%s"%year)

        for val in values.json():
            try:
                list_value.append(val['number'] or 0)
                            
            except:
                list_value.append(0)    
    feedback_form = get_feedback_form(request)
    response = render(request, 'graph/number_of_unemployed.html', locals())
    response.set_cookie(ISCO_COOKIE_NAME, isco)     
    return response




def average_length_of_unemployment(request):

    #set_tracking(request)
    isco_list = request.POST.getlist('isco_code')#get_isco_list(request)

    #isco=request.POST.get('isco_code','1112')
    years, year1, year2 = get_years(request)
    show_city_select = False
    list_value_mean = []
    list_value_std = []
    list_value_min = []
    list_value_percentile_25 = []
    list_value_percentile_50 = []
    list_value_percentile_75 = []
    list_value_max = []

    x_axis=[]
    modal = get_modal('average_length_of_unemployment')        
    title = _('Compare duration of Unemployment')
    iscos_graph_list = [] 
    for isco in isco_list:
        list_value=[]  
        list_value_mean=[]  
        for year in range(year1, year2+1):
            url = '%saverage_length_unemployment/?ISCO=%s&Year=%s'%(API_BASE_URL, isco, year)
            values = requests.get(url, timeout=10)   
            x_axis.append("%s"%year)

            for val in values.json():
                try:
                    list_value_mean.append(val['mean'] or 0)
                    #list_value_std.append(val['std'] or 0)
                    #list_value_min.append(val['min'] or 0)
                    #list_value_percentile_25.append(val['percentile_25'] or 0)
                    #list_value_percentile_50.append(val['percentile_50'] or 0)
                    #list_value_percentile_75.append(val['percentile_75'] or 0)                
                    #list_value_max.append(val['max'] or 0)                                
                except:
                    list_value_mean.append(0)
                    #list_value_std.append(0)
                    #list_value_min.append(0)
                    #list_value_percentile_25.append(0)
                    #list_value_percentile_50.append(0)
                    #list_value_percentile_75.append(0)                
                    #list_value_max.append(0)
        iscos_graph_list.append({'isco':get_isco_name(isco),'values':list_value_mean})       
            
    feedback_form = get_feedback_form(request)
    response = render(request, 'graph/average_length_of_unemployment.html', locals())
    #response.set_cookie(ISCO_COOKIE_NAME, isco)     
    return response

def average_length_of_unemployment_municipality(request):
    show_city_select = True
    set_tracking(request)
    isco=get_isco(request)
    years, year1, year2 = get_years(request)
    municipality = request.POST.get('Municipality',"")

    if not municipality:
        return average_length_of_unemployment(request)
    
    modal = get_modal('average_length_of_unemployment_municipality')        
    title = _('Average duration of unemployment')

    list_value_mean = []
    list_value_std = []
    list_value_min = []
    list_value_percentile_25 = []
    list_value_percentile_50 = []
    list_value_percentile_75 = []
    list_value_max = []

    x_axis=[]
    
    for year in range(year1, year2+1):
        url = '%saverage_length_unemployment_municipality/?Municipality=%s&ISCO=%s&Year=%s'%(API_BASE_URL, municipality, isco, year)
        values = requests.get(url, timeout=10)   
        x_axis.append("%s"%year)
        
        if values.json():
            for val in values.json():
                try:
                    list_value_mean.append(val['mean'] or 0)
                    list_value_std.append(val['std'] or 0)
                    list_value_min.append(val['min'] or 0)
                    list_value_percentile_25.append(val['percentile_25'] or 0)
                    list_value_percentile_50.append(val['percentile_50'] or 0)
                    list_value_percentile_75.append(val['percentile_75'] or 0)                
                    list_value_max.append(val['max'] or 0)                                
                except:
                    pass        
        else:
            list_value_mean.append(0)
            list_value_std.append(0)
            list_value_min.append(0)
            list_value_percentile_25.append(0)
            list_value_percentile_50.append(0)
            list_value_percentile_75.append(0)                
            list_value_max.append(0) 
    feedback_form = get_feedback_form(request)            
    response = render(request, 'graph/average_length_of_unemployment_municipality.html', locals())
    response.set_cookie(ISCO_COOKIE_NAME, isco)     
    return response



def format_axis(years):
    year_list=[]
    for year in years:
        #year_list.append(int(year*365))  
        year_list.append(round(year,1))
    return year_list


def format_volatility(hazard_rate,ciU,ciL_c, x_axis):
    i=0
    last=int(x_axis[-1])+1
    n=0
    for a in range(i,last):
        if int(x_axis[a])!=n:
            n = int(x_axis[a])
    
    pass

#@login_required
def volatility(request):
    set_tracking(request)
    isco = get_isco(request)
    age = int(request.POST.get('age','18'))
    ages = range(18,65)
    list_value = []
    x_axis=[]

    modal = get_modal('volatility')        
    title = _('Career Stability')
    if 1:
        url = '%svolatility/%s/%s/'%(API_BASE_URL_V2, isco, age)
        values = requests.get(url, timeout=10).json()  
        x_axis = format_axis(values["days"])


        hazard_rate = values["hazard_rate"]
        ciU = values["ciU"]        
        ciL = values["ciL"]  

         
        i=0
        varrak=[]
        for ci in ciL:
            varrak.append(([ci,ciU[i]]))
            i+=1
                     
    else:
        pass

    x_axis_title = 'Days'
    y_axis_title = ''
    feedback_form = get_feedback_form(request)    
    response = render(request, 'graph/volatility.html', locals())
    response.set_cookie(ISCO_COOKIE_NAME, isco)     
    return response


def liquidity(request, dtype, title):
    
    isco = get_isco(request)
    list_value = []
    list_jc = []
    list_jr = []    
    x_axis=[]

    modal = get_modal('liquidity_'+dtype.lower())         
    
    try:
        url = '%sliquidity/%s/'%(API_BASE_URL, isco)
        values = requests.get(url, timeout=10).json()
        x_axis = [datetime.fromtimestamp(x/1000000000).strftime('%Y-%m') for x in values["t"]]


        for val in values[dtype]:
            list_value.append(val)   
            
        for val in values['JC']:
            list_jc.append(val)                

        for val in values['JR']:
            list_jr.append(val)               



    except:
        pass

    list_value.reverse()
    x_axis.reverse()

    feedback_form = get_feedback_form(request)    
    response = render(request, 'graph/liquidity.html', locals())
    response.set_cookie(ISCO_COOKIE_NAME, isco)     
    return response

#http://pinta.ijs.si/hecat/api/v1/liquidity/0110/

#@login_required
def liquidity_jc(request):
    set_tracking(request)
    
    return liquidity(request,"JC", title)

#@login_required
def liquidity_jr(request):
    set_tracking(request)
    title = _("Net jobs created/destroyed per annum")
    return liquidity(request,"JR", title)

#@login_required
def liquidity_wr(request):
    set_tracking(request)
    title = _('Net people entering or leaving the employment')
    return liquidity(request,"WR", title)    




def liquidity_jc2(request):
    dtype='jc'
    title = _("Labour Market liquidity")
    isco = get_isco(request)
    list_value = []
    x_axis=[]
    
    modal = get_modal('liquidity_'+dtype.lower())         
    
    try:
        url = '%sliquidity/%s/JC/'%(API_BASE_URL_V2, isco)

        values = requests.get(url, timeout=10).json()
        x_axis = [datetime.fromtimestamp(x/1000000000).strftime('%Y-%m') for x in values["t"]]
        
        variable = values['variable'] #
        overallMean = values['overallMean'] #
        
        ciU = values['ciU']#values['statInterval']
        ciL = values['ciL'] 

        varrak=[]
        i=0
        for st in ciL:
            varrak.append(([st,ciU[i]]))
            i+=1

      
    except:
        pass

    list_value.reverse()
    x_axis.reverse()

    feedback_form = get_feedback_form(request)    
    response = render(request, 'graph/liquidity2.html', locals())
    response.set_cookie(ISCO_COOKIE_NAME, isco)     
    return response





def pex():
    pass

def pex2(request):
    set_tracking(request)
    
    isco = get_isco(request)
    list_value = []

    x_axis=[]

    modal = get_modal('pex')
    
    ages=range(18,65)
    months =range(1,100)
    title = _("Average time unemployed")
    education_direction = get_education_direction()
    reason_for_termination = get_reason_for_termination()
    employment_plan_ready = get_employment_plan_ready()
    unemployment_benefits = get_unemployment_benefits()
    gender = get_gender()
    social_support_benefits = get_social_support_benefits()
    education_level = get_education_level()
    employment_plan_status = get_employment_plan_status()
    occupation_code = get_occupation_code()
    municipality_id = get_municipality_idv2()
    
    
    params ={
            "education_direction": "001",
            "date_of_pes_entry": "2011-01-07",
            "municipality_id": 1,
            "months_work_experience": 15,
            "reason_for_termination": 0,
            "employment_plan_ready": 0,
            "unemployment_benefits": "D",
            "age": 25,
            "gender": 1,
            "social_support_benefits": "D",
            "education_level": "2",
            "employment_plan_status": 0,
            "occupation_code": "011"
            }     


    
    if request.method == 'POST':
        url = API_BASE_URL_V2+'pex/'
        
        params = request.POST.dict()
        orig_params = params
        params['age']=int(params.get('age','18'))
        params['months_work_experience']=int(params.get('months_work_experience','0'))        
        

        values = requests.post(url,json=params, timeout=10).json()

        time = [int(x) for x in values['time']]
        mean = values['mean']
        
        mcmc = values['mcmc']
        thrs = int(values['thrs'])
        Z = values['Z']
        p10 = int(values['p10']) # low confidence limit
        p50 = int(values['p50']) # median time to employment
        p90 = int(values['p90']) # high confidence limit        
       
    else:
        pass

    list_value.reverse()
    x_axis.reverse()
    feedback_form = get_feedback_form(request)    
    response = render(request, 'graph/pex2.html', locals())
    response.set_cookie(ISCO_COOKIE_NAME, isco)     
    return response    




   
        



def get_input_values(param):
    return requests.get(url='http://pinta.ijs.si/hecat/api/v1/pex_default/%s'%param).json()


def get_months_work_experience():
    return {a:a for a in range(0,70)}

def get_age():
    return {a:a for a in range(18,80)}


def get_municipality():
    return get_input_values('municipality_id')


def get_disability():
    return get_input_values('disability')


def get_employment_plan_status():
    return get_input_values('employment_plan_status')

def get_gender():
    return get_input_values('gender')

def get_occupation_code():
    return get_input_values('occupation_code')


def get_reason_for_entering_pes():
    return get_input_values('reason_for_entering_pes')

def get_employment_plan_ready():
    return get_input_values('employment_plan_ready')

def get_municipality_idv2():
    return get_input_values('municipality_id')


def get_input_valuesV2(param):
    return requests.get(url=API_BASE_URL_V2+'pex_default/%s'%param).json()


def get_education_direction():
    return get_input_valuesV2('education_direction')

def get_municipality_id():
    return get_input_valuesV2('municipality_id')

def get_reason_for_termination():
    return get_input_valuesV2('reason_for_termination')

def get_employment_plan_ready():
    return get_input_valuesV2('employment_plan_ready')

def get_unemployment_benefits():
    return get_input_valuesV2('unemployment_benefits')

def get_gender():
    return get_input_valuesV2('gender')

def get_social_support_benefits():
    return get_input_valuesV2('social_support_benefits')

def get_education_level():
    return get_input_valuesV2('education_level')

def get_employment_plan_status():
    return get_input_valuesV2('employment_plan_status')

def get_occupation_code():
    return get_input_valuesV2('occupation_code')





