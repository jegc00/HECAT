from modeltranslation.translator import register, TranslationOptions
from .models import GraphInfo, ISCOCode

@register(GraphInfo)
class GraphInfoTranslationOptions(TranslationOptions):
    fields = ("title","description" ,"slug", "body","feedback_text","extra_text")
    
@register(ISCOCode)
class GraphInfoTranslationOptions(TranslationOptions):
    fields = ("description",)
    
    
