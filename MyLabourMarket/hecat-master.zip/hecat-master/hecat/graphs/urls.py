from django.urls import path
from .views import (job_number_of_employed, average_income,estimated_vacancies, 
                    number_of_first_employed_isco, average_length_of_unemployment, 
                    average_length_of_unemployment_municipality, liquidity_jc, liquidity_wr,
                    liquidity_jr, volatility, number_of_unemployed, average_number_of_entrants,pex, pex2, 
                    number_of_first_employed_nace, liquidity_jc2)

urlpatterns = [
    path('job_number_of_employed/', job_number_of_employed, name='job_number_of_employed'),           
    path('average_income/', average_income, name='average_income'),           
    path('average_number_of_entrants/', average_number_of_entrants, name='average_number_of_entrants'),  

    path('number_of_first_employed_nace/', number_of_first_employed_nace, name='number_of_first_employed_nace'),           
        
    path('estimated_vacancies/', estimated_vacancies, name='estimated_vacancies'),           
    path('number_of_first_employed_isco/', number_of_first_employed_isco, name='number_of_first_employed_isco'),               
    path('average_length_of_unemployment/', average_length_of_unemployment, name='average_length_of_unemployment'),               
    path('average_length_of_unemployment_municipality/', average_length_of_unemployment_municipality, name='average_length_of_unemployment_municipality'),                   
    path('liquidity/jc/', liquidity_jc, name='liquidity_jc'),                   
    path('liquidity/wr/', liquidity_wr, name='liquidity_wr'),                   
    path('liquidity/jr/', liquidity_jr, name='liquidity_jr'),  
    path('liquidity2/', liquidity_jc2, name='liquidity2'),      
                         
    path('volatility/', volatility, name='volatility'),      
    path('number_of_unemployed/', number_of_unemployed, name='number_of_unemployed'),      
    path('pex_old/', pex, name='pex_old'),      
    path('pex/', pex2, name='pex'),      

    
]