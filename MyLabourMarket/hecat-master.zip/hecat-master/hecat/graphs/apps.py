from django.apps import AppConfig


class GraphsConfig(AppConfig):
    name = 'hecat.graphs'
