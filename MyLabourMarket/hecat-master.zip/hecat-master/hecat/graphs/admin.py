from django.contrib import admin
from .models import *

class ISCOCodeAdmin(admin.ModelAdmin): 
    list_display = ('code','description')
    fieldsets = (
        ('English', {
            "fields": ('description_en',)
            }
        ),
        ('Slovenian', {
            "fields": ('description_sl',)
        }
        ),
    )
    

class NaceCodeAdmin(admin.ModelAdmin): 
    list_display = ('level', 'code', 'parent', 'description')
    list_filter = ('parent',)
 
 
class GraphInfoAdmin(admin.ModelAdmin): 
    list_display = ('title', 'slug', 'body')
    fieldsets = (
        ('English', {
            "fields": ('title_en','slug_en','description_en','body_en','feedback_text_en','extra_text_en')
            }
        ),
        ('Slovenian', {
            "fields": ('title_sl','slug_sl','description_sl','body_sl','feedback_text_sl','extra_text_sl')
        }
        ),
    )
    
admin.site.register(ISCOCode, ISCOCodeAdmin)
admin.site.register(NACECode, NaceCodeAdmin)    
admin.site.register(GraphInfo, GraphInfoAdmin)    

