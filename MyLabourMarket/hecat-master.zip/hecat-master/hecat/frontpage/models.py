from django.db import models
from photologue.models import Photo
from django.core.validators import MinValueValidator

class Header(models.Model):
    title = models.CharField(max_length=255)
    subtitle = models.CharField(max_length=255)
    body = models.TextField()

class Feature(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField()
    photo = models.ForeignKey(Photo, null=True, blank=True, on_delete=models.SET_NULL)
    link = models.CharField(max_length=300, null=True, blank=True)
    order = models.PositiveIntegerField(validators=[MinValueValidator(1)])

    def get_photo(self):
        return self.photo.image.url
