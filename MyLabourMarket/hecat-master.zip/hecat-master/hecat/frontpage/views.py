from django.shortcuts import render
from .models import Header, Feature
from hecat.tipoftheday.models import Tip
from hecat.graphs.views import get_teaser_1, get_teaser_1, get_teaser_2, get_teaser_3, get_teaser_4, get_teaser_5

def index(request):
    header = Header.objects.all().first()
    features = Feature.objects.all()
    tip = Tip.objects.all().order_by('?').first()
    isco = request.POST.get('isco_code')  
    if request.method=='POST':
        t1 = get_teaser_1(request) #number_of_employed_teaser
        t2 = get_teaser_2(request) #salary_teaser
        t3 = get_teaser_3(request) #number_unemployed_teaser
        t4 = get_teaser_4(request) #unemployment_length_teaser
        t5 = get_teaser_5(request) #vacancies_teaser
    
    return render(request, 'index.html', locals())




def labour_market_trends(request):
    return render(request, 'labour-martket-trends.html', locals())
    