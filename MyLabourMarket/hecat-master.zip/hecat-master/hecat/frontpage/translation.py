from modeltranslation.translator import register, TranslationOptions
from .models import Header, Feature

@register(Header)
class GraphInfoTranslationOptions(TranslationOptions):
    fields = ("title", "subtitle", "body")

@register(Feature)
class GraphInfoTranslationOptions(TranslationOptions):
    fields = ("title", "description", "link")
    