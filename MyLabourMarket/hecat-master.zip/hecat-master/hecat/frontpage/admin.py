from django.contrib import admin
from .models import *

class HeaderAdmin(admin.ModelAdmin):
    list_display = ('title', 'subtitle', 'body')
    fieldsets = (
        ('English', {
            "fields": ('title_en','subtitle_en','body_en')
            }
        ),
        ('Slovenian', {
            "fields": ('title_sl','subtitle_sl','body_sl')
        }
        ),
    )

    def has_add_permission(self, request):
        return not Header.objects.exists()

class FeatureAdmin(admin.ModelAdmin):
    list_display = ('title', 'description', 'photo', 'link', 'order')
    fieldsets = (
        ('English', {
            "fields": ('title_en','description_en', 'link_en')
            }
        ),
        ('Slovenian', {
            "fields": ('title_sl','description_sl', 'link_sl')
        }
        ),
        ('General',{
            "fields": ('photo', 'order')
        }
        ),
    )
    ordering = ('order',)
        
admin.site.register(Header, HeaderAdmin)
admin.site.register(Feature, FeatureAdmin)

