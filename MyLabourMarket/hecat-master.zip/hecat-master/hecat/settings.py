# -*- encoding: utf-8 -*-
import os

# Build paths inside the project like this: os.path.join(BASE_DIR, ...)
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


# Quick-start development settings - unsuitable for production
# See https://docs.djangoproject.com/en/1.11/howto/deployment/checklist/

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = "+0xkgr_o=j1nfyhiq%7-i%+k+b8vj^6f+e=!6w^%-frf-%r321"

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = True

ALLOWED_HOSTS = ["localhost", "www.mylabourmarket.com"]

# MODEL TRANSLATION

gettext = lambda s: s

LANGUAGE_CODE = "sl"
DEFAULT_LANGUAGE = LANGUAGE_CODE

LANGUAGES = (("sl", "Slovenščina"), ("en", "English"))

MODELTRANSLATION_DEFAULT_LANGUAGE = DEFAULT_LANGUAGE


MAPBOX_KEY = "pk.eyJ1IjoiamF0c3UiLCJhIjoiY2tlaWluNmM2MGt0YzMwbzZtYjlseG1rbCJ9.iVD0JlKT2Ga97nA8Q0gghw"





REST_FRAMEWORK = {
    'DEFAULT_PERMISSION_CLASSES': (
        'rest_framework.permissions.DjangoModelPermissions',
    )
}

INSTALLED_APPS = [
    "modeltranslation",
    "ckeditor",
    "mptt",
    "pages",    
    "django.contrib.auth",
    "django_registration",
    "baton",
    "django.contrib.admin",
    "django_object_actions",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "django.contrib.sites",
    "photologue",
    "multiselectfield",
    "bootstrap4",
    'rest_framework',
    'rest_framework.authtoken',
    'import_export',
    #"baton.autodiscover",
    "structured_data",
    "bootstrap_pagination",
    "drfformbootstrap4",
    "hecat.users",
    "hecat.graphs",
    "hecat.frontpage",
    "hecat.tracking",
    "hecat.feedbacks",   
    "hecat.tipoftheday",
    "hecat.job_quality",    
    "hecat",
    "django_htmx",
    "leaflet", 
    "djgeojson",
]

DATETIME_FORMAT = 'Y-m-d H:i'


AUTH_USER_MODEL = "users.HecatUser"

DEFAULT_PAGE_TEMPLATE = "cms_page.html"
PAGE_DEFAULT_TEMPLATE = DEFAULT_PAGE_TEMPLATE

PAGE_TEMPLATES = ((DEFAULT_PAGE_TEMPLATE, 'General'),)




EMAIL_HOST='localhost'
EMAIL_HOST_USER=''
EMAIL_HOST_PASSWORD=''

DEFAULT_FROM_EMAIL = ""

X_FRAME_OPTIONS = "SAMEORIGIN"

PAGE_LANGUAGES = LANGUAGES

TEMPLATE_CONTEXT_PROCESSORS = ("pages.context_processors.media",)




MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.locale.LocaleMiddleware",
    #"django.middleware.csrf.CsrfViewMiddleware",
    "hecat.middle.DisableCSRFMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
    "django_htmx.middleware.HtmxMiddleware",
]

AUTH_AUTHENTICATION_TYPE = 'both'


AUTHENTICATION_BACKENDS = [
    'django.contrib.auth.backends.ModelBackend',
    'hecat.users.backends.EmailAuthBackend',
    #'hecat.users.backends.EmailOrUsernameModelBackend',    
]


#
REST_FRAMEWORK = {
    # Use Django's standard `django.contrib.auth` permissions,
    # or allow read-only access for unauthenticated users.
    'DEFAULT_PERMISSION_CLASSES': [
        'rest_framework.permissions.DjangoModelPermissionsOrAnonReadOnly'
    ]
}

DEFAULT_AUTO_FIELD='django.db.models.AutoField' 
ROOT_URLCONF = "hecat.urls"
SITE_ID = 1

LOGIN_REDIRECT_URL = "/"  
LOGOUT_REDIRECT_URL = "/"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.debug",
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.template.context_processors.i18n",
                "django.contrib.messages.context_processors.messages",
                "pages.context_processors.media",
            ],
        },
    },
]

WSGI_APPLICATION = "hecat.wsgi.application"



DATABASES = {
    "default": {
        "NAME": "",
        "HOST": "localhost",
        "ENGINE": "django.db.backends.mysql",
        "USER": "",
        "PASSWORD": "",
    },
    
}



AUTH_PASSWORD_VALIDATORS = [
    {
        "NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator",
    },
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator",},
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator",},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator",},
]




TIME_ZONE = "Europe/Madrid"

USE_I18N = True

USE_L10N = True

USE_TZ = True
CSRF_COOKIE_SECURE = False
SESSION_COOKIE_SECURE = False
CSRF_USE_SESSIONS = False

STATIC_URL = "/static/"
STATIC_ROOT = '/home/tecnalia/django/static/'

MEDIA_URL = "/media/"
MEDIA_ROOT = "/home/tecnalia/django/media/"

ACCOUNT_ACTIVATION_DAYS = 7  # One-week activation window

LANGUAGE_COOKIE_NAME = "django_language"



try:
    from .baton_settings import *
except:
    pass


