import $ from 'jquery'

let PasswordChange = {
  init: function () {
    $('body').addClass('passwordchange')
  }
}

export default PasswordChange
