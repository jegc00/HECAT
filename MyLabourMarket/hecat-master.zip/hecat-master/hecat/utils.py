from geopy.geocoders import Nominatim
import requests
from operator import itemgetter    

def get_city_name(id):
    current_municipality = requests.get(
        "http://pinta.ijs.si/hecat/api/v2/default_dss_values/minucipality_wishes").json() 
    for city in current_municipality:
        print(city, id)
        if city[0]==id:
            return city[1]
    return 'LJUBLJANA'       

def get_city_lat_lon(name):
    locator = Nominatim(user_agent="myGeocoder")    
    ll = locator.geocode(name)        
    center = "%s, %s "%(ll[1][0],ll[1][1])    
    return center
    
    
def get_city_lat_lon_by_id(id):
    city = get_city_name(id)
    return  get_city_lat_lon(city)


def order_tuple_list(lista, by_n=1):
    return sorted(lista, key=itemgetter(by_n))