from django.apps import AppConfig


class FrontpageConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'hecat.job_quality'
