from django.urls import path
from .views import (index, map)

urlpatterns = [
    path('', index, name='job-quality'),    
    path('map', map, name='job-quality-map'),        
    
]