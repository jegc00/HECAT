from django.shortcuts import render
from hecat.graphs.views import API_BASE_URL
import requests
from django.contrib.auth.decorators import login_required
from hecat.graphs.views import API_BASE_URL, get_feedback_form, get_modal
from hecat.utils import get_city_lat_lon_by_id
from django.utils.translation import gettext, gettext_lazy as _

example_dict = {
    "ISCO": [
        "3132"
    ],
    "municipality_id": 2,
    "Distance to work": 15,
    "user wishes for working time": "Part-time",
    "job working time": "Part-time",
}
extra = {
  "Pay and other rewards": True,
  "Educational requirement": True,
  "Job security": True,
  "Job type": True,
  "Non-standard woring time": True,
  "Flexibility of working time": True,
  "Representation at the firm level": True,
  "Self-assessed Quality of employer": True
}



#@login_required
def index(request):
    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json',
    }
    rows = []
    current_municipality = requests.get(
        "http://pinta.ijs.si/hecat/api/v2/default_dss_values/minucipality_wishes").json()
    feedback_form = get_feedback_form(request)      
    if request.method == "POST":

        post_dict = request.POST.dict()
        selected_codes = request.POST.getlist('isco_code')[0]

        post_dict.pop('csrfmiddlewaretoken')
        post_dict.pop('isco_code')
        selected_filters=[]
        new_dict = {}
        sel_dict = {}
        for k, v in post_dict.items():
            if v == '1':
                new_dict[k] = True
                sel_dict[k.replace(' ', '_').replace('-','_')] = True
                selected_filters.append(k)
            else:
                new_dict[k] = v
                sel_dict[k.replace(' ','_').replace('-','_')] = v
                
        #new_dict["Distance to work"] = 0#int(new_dict["Distance to work"])
        if 'municipality_id' in sel_dict.keys():
            sel_dict['municipality_id'] = int(sel_dict['municipality_id'])

        for isco in request.POST.getlist('isco_code'):
            new_dict["ISCO"] = [isco]
            new_dict['municipality_id'] = int(new_dict['municipality_id'])
            print(new_dict)
            data1 = requests.post('http://pinta.ijs.si/hecat/api/v2/job_quality/',
                                 headers=headers, json=new_dict)
            if data1.status_code==200:
                data = data1.json()
                grouped={}
                points = []
                
                for item in data:
                    if item.get('isco') in  grouped:
                        grouped[item.get('isco')].append(item)
                    else:    
                        grouped[item.get('isco')] = [item]
                    

                    contract_type=item['job working time']
                    earnings_upper=item['Upper quartile']
                    earnings_median=item['Median']
                    earnings_lower=item['Lower quartile']
                    url = item['url']
                    title = _("""
                    <strong>%s</strong><br />
                    <strong>Company:</strong> <u>%s</u> <br />%s <br />
                    <strong>Contract Type:</strong> %s <br />
                    <strong>Earnings:</strong> <br />
                    - 25&percnt; workers  earn more than %s&euro; <br/>
                    - The average salary is %s&euro; <br />
                    - 25&percnt; workers  earn less than %s&euro;<br />
                    <strong><a target='_blank' href='%s'>URL</a></strong><br/>""")%(item['positionTitle'], item['companyName'],item['location'],contract_type,earnings_upper,earnings_median, earnings_lower, url )


                    title = "".join(title.splitlines())
                    lat_lon_list = item['geoJson']['geometry']['coordinates']
                    prop = item['geoJson']['geometry']['properties']['max']
                    print(prop)
                    #title+=str("<strong>prop max:</strong> "+str(prop))
                    if prop < 50:
                        icon = "{icon: redIcon}"
                    elif prop>50 and prop <75:
                        icon = "{icon: orangeIcon}"   
                    else:
                        icon=""     
                    #item['geoJson']['geometry']['properties']['max']
                    #item['geoJson']['geometry']['properties']['min']
                    lat_lon = "%f,%f"%(lat_lon_list[1],lat_lon_list[0])
                    # eta 
                    points.append({'lat_lon':lat_lon,'title':title,'icon':icon ,'prop':prop})    
            else:
                no_data=True
    try:            
        center = get_city_lat_lon_by_id(new_dict['municipality_id'])
    except:                        
        center = '46.056946, 14.505751'

    zoom='9'
            
    response = render(request, 'job_quality/index_new.html', locals())
    return response



 

def map(request):
    headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json',
    }
    rows = []
    new_dict={
                "ISCO": [
                    "3221"
                ],
                "municipality_id": 64,
                "Distance to work": 20,
                "user wishes for working time": "Part-time",
                "Pay and other rewards": True,
                "Educational requirement": True,
                "Autonomy and control": True,
                "Meaningfulness of the job": True,
                "Job security": True,
                "Training opportunities": True,
                "Job type": True,
                "Physical risk": True,
                "Psycho-social risks": True,
                "job working time": True,
                "Non-standard woring time": True,
                "Flexibility of working time": True,
                "Representation at the firm level": True,
                "Self-assessed Quality of employer": True
                }
    
    
    data1 = requests.post('http://pinta.ijs.si/hecat/api/v2/job_quality/', headers=headers, json=new_dict)
    
    data=data1.json()
    center = '46.056946, 14.505751'
    zoom='10'
    points=[]
    for job in data:
        title = "<strong>%s</strong><br /><u>%s</u> <br />%s"%(item['positionTitle'], item['companyName'],item['location'])
        lat_lon_list = item['geoJson']['geometry']['coordinates']
        lat_lon = "%f,%f"%(lat_lon_list[1],lat_lon_list[0])
        points.append({'lat_lon':lat_lon,'title':title})

    p3 = {'lat_lon':'46.046319884545255, 14.495007173368974', 'title':'BTC City Ljubijana'}
    p2 = {'lat_lon':center,'title':'Ljubljana'}
    
    
    response = render(request, 'job_quality/map.html', locals())
    
    return response    


