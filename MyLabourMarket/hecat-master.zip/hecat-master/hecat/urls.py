#from django.contrib import admin
from baton.autodiscover import admin

from django.conf.urls import url, include
from django.conf.urls.i18n import i18n_patterns
from django.utils.translation import ugettext_lazy as _
from django.urls import path
from django.conf import settings
from django.views.static import serve
from django.views.generic import TemplateView

from hecat.users.views import HecatRegistrationView, HecatRegistrationExpertOk, HecatRegistrationOk, ExpertRegistrationView
from hecat.users.forms import HecatUserForm, HecatUserForm2

from django.contrib.auth import views as auth_views
from django.views.generic import TemplateView

from hecat.whatif.views import index as what_if_index, whatif_graph
from hecat.frontpage.views import index as frontpage_index, labour_market_trends

patterns_i18 = i18n_patterns(
    path('', frontpage_index, name='frontpage_index'),
    path('labour-market-trends/', labour_market_trends, name='labour_market_trends'),             
    path('job_number_of_employed', TemplateView.as_view(template_name='graph1.html'), name='job_number_of_employed'),     
    
    path(
        'accounts/register/', 
         HecatRegistrationView.as_view(
            form_class=HecatUserForm, 
            template_name="django_registration/registration_form.html",
        ),
        name='django_registration_register',
    ),    

    path(
        'accounts/expert/register/', 
         ExpertRegistrationView.as_view(
            form_class=HecatUserForm2, 
            template_name="django_registration/registration_form2.html",
        ),
        name='django_registration_expert_register',
    ),    
    path('test/', TemplateView.as_view(template_name='test.html'), name='test'),
    path('register/type/', TemplateView.as_view(template_name='registration/select_register_type.html'), name='register_type'),


    path('accounts/ok/<slug:username>', HecatRegistrationOk.as_view(), name='register_ok'),    
    path('accounts/expert/ok/<slug:username>', HecatRegistrationExpertOk.as_view(), name='register_ok_expert'),    
    
    path('what_if/', what_if_index, name='what_if'),    
    path('whatif_graph/', whatif_graph, name='whatif_graph'),    
    
    path('accounts/login/', auth_views.LoginView.as_view(), name="auth_login"),    
    path('accounts/', include('django_registration.backends.activation.urls')),
    path('accounts/', include('django.contrib.auth.urls')),               
    path('graphs/', include('hecat.graphs.urls')),            
    path('feedbacks/', include('hecat.feedbacks.urls')),            
    path('job_quality/', include('hecat.job_quality.urls')),            
    

    path('', include('pages.urls')),        

)

urlpatterns = patterns_i18+[
    path('admin/', admin.site.urls),
    path('baton/', include('baton.urls')),
    path(_('deep/'), TemplateView.as_view(template_name='deep.html'), name='estatikoa1'),
    path(_('general/'), TemplateView.as_view(template_name='general.html'), name='estatikoa2'),

    path('gulp', TemplateView.as_view(template_name='gulpekoa.html'), name='estatikoa3'),


    path('i18n/', include('django.conf.urls.i18n')),
    path('photos/', include('photologue.urls', namespace='photologue')),
    path('media/photologue/photos/', include('photologue.urls', namespace='photologue_media')),

]

if settings.DEBUG:
    urlpatterns += [
        url(r'^media/(?P<path>.*)$', serve, {
            'document_root': settings.MEDIA_ROOT,
        }),
    ]
