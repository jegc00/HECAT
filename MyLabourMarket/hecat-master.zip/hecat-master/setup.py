from setuptools import setup, find_packages
import sys, os

version = '0.0'

setup(name='hecat',
      version=version,
      description="",
      long_description="""\
""",
      classifiers=[], # Get strings from http://pypi.python.org/pypi?%3Aaction=list_classifiers
      keywords='',
      author='',
      author_email='',
      url='',
      license='',
      packages=find_packages(exclude=['ez_setup', 'examples', 'tests']),
      include_package_data=True,
      zip_safe=False,
      install_requires=[
          'mysqlclient==2.0.3',
          'django-photologue',
          'django-parler',
          'gunicorn',
          'bootstrap-admin',
          'django-modeltranslation>0.15',
          'django-location-field',
          'django-baton==1.12.1',
          'django-ckeditor',
          'django-page-cms==2.0.11',
          'django-multiselectfield',
          'django-registration',
          'django-bootstrap4',
          'django-leaflet==0.28.0',
          'django-object-actions',
          'Pillow',
          'reportlab',
          'babel',
          'pdfkit', # requires wkhtmltopdf installation: sudo apt-get install wkhtmltopdf
          'django-structured-data',
          'suds-py3',
          'XlsxWriter==1.3.6',
          'django-bootstrap-pagination',
          'djangorestframework',
          'drf-form-bootstrap-4',
          'django-import-export',
          'django-htmx',
          'django-geojson',
          'geopy'
      ],
      entry_points="""
      # -*- Entry points: -*-
      """,
      )
